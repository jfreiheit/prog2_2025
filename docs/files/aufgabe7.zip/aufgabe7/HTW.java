package aufgaben.aufgabe7;

public class HTW
{
    private SG[] htw;

    public HTW(Studentin[] studis) {
        /*
        Erstellen Sie eine Name[] sgs, das alle Namen der Studiengänge enthält, in denen
        die Studentinnen aus dem studis-Array studieren

        Verwenden Sie Streams. Schauen Sie sich folgende Methoden an
        - stream() aus der Klasse Arrays
        - map()             // um aus dem Studentinnen-Stream einen Studiengangs-Stream zu machen
        - distinct()        // um alle Doppelungen heraus zu filtern
        - toArray()         // um ein Name-Array zu erzeugen
         */
        Name[] sgs = new Name[0]; // TODO

        this.htw = new SG[sgs.length];
        for (int i = 0; i < sgs.length; i++) {
            htw[i] = new SG(studis, sgs[i].toString());
        }
    }
    public int anzahlStudis() {
        /*
        Ermitteln Sie die Summe aller Studentinnen aus dem htw-Array.

        Verwenden Sie Streams. Schauen Sie sich folgende Methoden an
        - stream() aus der Klasse Arrays
        - mapToInt()        // um die anzahlStudis (siehe SG) pro SG zu ermitteln
        - sum()             // um die Summe der Anzahlen zu ermitteln
         */
        return 0;   // TODO
    }

    @Override
    public String toString()
    {
        String s = String.format("HTW mit %d Studierenden in %d Studiengaengen : %n%n",
                this.anzahlStudis(), this.htw.length);
        for (int index = 0; index < this.htw.length; index++)
        {
            s += this.htw[index].toString();
        }
        s += "\n";
        return s;
    }

    public Studentin[] nochStudierend()
    {
        /*
        Erzeugen Sie ein Studentin[] aller noch Studierenden aus dem htw-Array.

        Verwenden Sie Streams. Schauen Sie sich folgende Methoden an
        - stream() aus der Klasse Arrays
        - flatMap()        // um alle nochStudierend (siehe SG) pro SG zu ermitteln
        - toArray()        // um das Studentin[] zu erzeugen (und mit dem Stream zu befuellen)
         */
        return new Studentin[0];
    }
}
