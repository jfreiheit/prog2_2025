package aufgaben.aufgabe7;

import java.util.Arrays;

public class Name {

    private char[] name;

    public Name(String name) {
        this.name = name.toCharArray();
    }

    @Override
    public String toString() {
        String s = "";
        for(char c : this.name) {
            s += c;
        }
        return s;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Name other = (Name) o;

        return Arrays.equals(this.name, ((Name) o).name);
    }

    public boolean isBigger(Name n) {
        int length = this.name.length < n.name.length ? this.name.length : n.name.length;
        for (int index = 0; index < length; index++) {
            if (this.name[index] > n.name[index]) return true;
            else if (this.name[index] < n.name[index]) return false;
        }
        return this.name.length > n.name.length;
    }

}
