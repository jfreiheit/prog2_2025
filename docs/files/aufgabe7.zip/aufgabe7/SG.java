package aufgaben.aufgabe7;


public class SG
{
    private Studentin[] studis;
    private Name sg;

    public SG(Studentin[] studis, String sg) {
        this.sg = new Name(sg);
        /*
        Das studis-Array des Parameters enthält Studentin-Objekte aus verschiedenen
        Studiengängen. Ermitteln Sie, wie viele Studentin-Objekte es für den
        Studiengang sg enthält und erzeugen Sie das studis-Array der Objektvariablen
        entsprechend.

        Befüllen Sie das studis-Array der Objektvariablen mit allen Studentin-Objekten
        aus dem studis-Array des Parameters, die zum Studiengang sg gehören.

        Nutzen Sie dazu Streams!
         */
        this.studis = new Studentin[0]; // TODO
    }

    public int anzahlStudis() {
        return this.studis.length;
    }

    public void sort(boolean note) {
        /*
        Sortieren Sie das studis-Array.

        Ist der Parameterwert von note true, wird das Array nach dem Notendurchschnitt
        sortiert (beste Note zuerst).
        Ist der Parameterwert von note false, wird das Array nach der Anzahl der Semester
        sortiert (wenigsten Semester zuerst).

        Nutzen Sie dazu die Sortier-Methode sort(T[] a, Comparator c) aus der Klasse Arrays
        Schauen Sie sich für einen passenden Comparator die compare()-Methoden der Klassen
        Double und Integer an!

        Verwenden Sie Lambdas!
         */
    }

    @Override
    public String toString()
    {
        String s = String.format("%s mit %d Studis : %n", this.sg, this.studis.length);
        for(int index = 0; index < this.studis.length; index++)
        {
            s += String.format("   %s %n", this.studis[index].toString());
        }
        s += "\n";
        return s;
    }

    public Studentin besterAbschluss() {
        /*
        Geben Sie die Studentin zurück, die den besten Notendurchschnitt von allen
        Absolventinnen (mit 180 Leistungspunkten) des Studiengangs hat.

        Verwenden Sie Streams. Schauen Sie sich folgende Methoden an
        - stream() aus der Klasse Arrays
        - filter()  // um alle Absolventinnen zu filtern
        - min()     // um diejenige mit der besten Note zu ermitteln
         */
        return null;    // TODO
    }

    public double durchschnittlicheAbschlussnote() {
        /*
        Geben Sie den durchschnittlichen Notenwert (als double) aller Absolventinnen
        (mit 180 Leistungspunkten) des Studiengangs zurück.

        Verwenden Sie Streams. Schauen Sie sich folgende Methoden an
        - stream() aus der Klasse Arrays
        - filter()          // um alle Absolventinnen zu filtern
        - mapToDouble()     // oder map() - um den Studentinnen-Stream in einen Noten-Stream zu wandeln
        - average()
         */
        return 0.0; //TODO
    }

    public Studentin[] nochStudierend() {
        /*
        Geben Sie ein Studentin[] zurück, das alle Studentinnen aus dem Studiengang enthält,
        die noch keine 180 Leistungspunkte haben.

        Verwenden Sie Streams. Schauen Sie sich folgende Methoden an
        - stream() aus der Klasse Arrays
        - filter()          // um alle Studentinnen mit weniger als 180 LP zu filtern
        - toArray()         // um ein Studentin-Array zu erzeugen
         */
        return new Studentin[0]; // TODO
    }
}
