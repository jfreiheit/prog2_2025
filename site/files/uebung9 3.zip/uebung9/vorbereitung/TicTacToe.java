package uebungen.uebung9.vorbereitung;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.BorderFactory;
import javax.swing.JButton;

public class TicTacToe extends JFrame
{
	JLabel label;
	JPanel mainPanel, buttonPanel;
	JPanel[] field;
	enum Player { x, o }
	Player currentPlayer;
	
	TicTacToe()
	{
		super();
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("TicTacToe");
		this.setSize(600, 600);
		this.setLocation(200,100);
		this.currentPlayer = Player.x;
		this.label = new JLabel("x ist dran");
		this.label.setFont(new Font("Verdana", Font.BOLD, 36));
		this.label.setHorizontalAlignment(JLabel.CENTER);
		this.getContentPane().add(this.label, BorderLayout.NORTH);
		
		this.mainPanel = createMainPanel();
		this.getContentPane().add(this.mainPanel, BorderLayout.CENTER);
		
		this.buttonPanel = createButtonPanel();
		this.getContentPane().add(this.buttonPanel, BorderLayout.SOUTH);
		
		this.setVisible(true);
		this.mausKlicksBehandeln();		// das mainPanel wird an den MouseListener angemeldet
	}
	
	JPanel createMainPanel()
	{
		JPanel main = new JPanel();
		main.setLayout(new GridLayout(3,3,10,10));
		this.field = new JPanel[9];
		for(int index = 0; index < this.field.length; index++)
		{
			this.field[index] = new JPanel();
			this.field[index].setLayout(new BorderLayout());
			this.field[index].setBackground(Color.WHITE);
			this.field[index].setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
			main.add(this.field[index]);
		}
		return main;
	}
	
	JPanel createButtonPanel()
	{
		JPanel buttons = new JPanel();
		JButton startBtn = new JButton("start");
		buttons.add(startBtn);
		return buttons;
	}
	
	void mausKlicksBehandeln() {
		// MouseListener wird dem mainPanel als anonyme Klasse angemeldet
		this.mainPanel.addMouseListener(new MouseListener() {

			@Override
			public void mouseClicked(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mousePressed(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseExited(MouseEvent e) {
				// TODO Auto-generated method stub
				
			}
			
		});
	}

	public static void main(String[] args) {
		new TicTacToe();

	}

}
