package uebungen.uebung9;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class Controller implements ActionListener
{
    Model model;
    View view;

    Controller(Model model, View view) {
        this.model = model;
        this.model.restart();
        this.view = view;
        for(int i = 0; i < this.view.buttons.length; i++) {
            this.view.buttons[i].addActionListener(this);
        }
        this.view.btnStart.addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        // TODO

    }
}
