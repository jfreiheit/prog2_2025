package uebungen.uebung9;

public class Programclass 
{

    public static void main(String[] args) 
    {
        Model model = new Model(3); 
        model.playGame();   // einmal ein Spiel auf Konsole ausgeben
        View view = new View(model);
        Controller controller = new Controller(model, view);
    }

}
