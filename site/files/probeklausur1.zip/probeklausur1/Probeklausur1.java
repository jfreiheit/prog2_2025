package probeklausuren.probeklausur1;

import java.util.*;

public class Probeklausur1
{
    static Random r =  new Random();

    public static Circle createCircle(int bound)
    {
        int randNr = r.nextInt(bound);
        if(randNr < 2)
        {
            return new Circle();
        }
        else
        {
            return new Circle(randNr);
        }
    }

    public static List<Circle> setUpCircleList(int listLength, int bound)
    {
        List<Circle> list = new ArrayList<Circle>();
        for(int i = 0; i < listLength; i++)
        {
            list.add(createCircle(bound));
        }
        return list;
    }

    /*
     *   gibt eine Liste mit allen Elementen aus c1 UND c2 zurueck
     *   in der Liste darf jedoch kein Element doppelt vorkommen, d.h.
     *   wenn e1 in Liste und e2 in Liste, dann gilt !e1.equals(e2)
     */
    public static List<Circle> union(List<Circle> c1, List<Circle> c2)
    {
        return null; //TODO
    }


    /*
     *   gibt eine Map zurueck
     *   Schluessel sind die Flaecheninhalte (area) der Circles
     *   Werte sind eine Liste aller Circle-Objekte mit diesem Flaecheninhalt
     */
    public static Map<Double, List<Circle>> createMap(List<Circle> circles)
    {
        return null; //TODO
    }

    /*
     *   fuegt der map alle circles passend hinzu
     */
    public static void addListToMap(Map<Double, List<Circle>> map, List<Circle> circles)
    {
        //TODO
    }

    /*
     *   - uebergeben wird eine map, deren keys vom Typ Double sind
     *   - der Schluessel key ist vom Typ int
     *   - in der map wird nach einem Schluessel gesucht, dessen ganzzahliger
     *      Wert dem int key entspricht, d.h.
     *          78,654 passt zu 78
     *          79,01 passt nicht zu 78
     *   - falls ein solcher Schluessel nicht in der map existiert, wird eine
     *      IllegalArgumentException geworfen. Die Nachricht enthaelt den Wert des
     *      Schlussels, nach dem gesucht wurde, z.B. 'key 79 not found'
     *   - falls ein solcher Schluessel existiert, wird der erste Circle aus der
     *      Liste zu dem Schluessel zurueckgegeben
     */
    public static Circle getFirstCircleOfKey(Map<Double, List<Circle>> map, int key)
    {
        return null; //TODO
    }

    /*
     *   - uebergeben wird eine map, deren keys vom Typ Double sind (area())
     *   - die Werte sind vom Typ List<Circle>
     *   - in der map (in den values) wird nach einem Circle gesucht, dessen
     *     Radius dem Parameterwert von double radius entspricht
     *   - falls ein solcher Circle existiert, wird er dem Optional hinzugefuegt
     *     und zurückgegeben
     *   - falls ein solcher Circle nicht existiert, wird ein leeres Optional
     *     zurueckgegeben
     */
    public static Optional<Circle> getFirstCircleOfRadius(Map<Double, List<Circle>> map, double radius)
    {
        return null; //TODO
    }

    /*
     * uebergeben wird eine unsortierte Liste von Circle-Objekten
     * zurueckgegeben wird eine sortierte Liste von Circle-Objekte
     * sortiert nach "natural order" (compareTo)
     */
    public static List<Circle> createSortedListOfCircles(List<Circle> circles)
    {
        return null; //TODO
    }

    /*
     * uebergeben wird eine unsortierte Liste von Circle-Objekten
     * zurueckgegeben wird eine sortierte Liste von Circle-Objekte
     * - sortiert nach "natural order" (compareTo)
     * - gerade Radien zuerst!!!
     */
    public static List<Circle> createSortedListOfCirclesEvenRadiiFirst(List<Circle> circles)
    {
        return null; //TODO
    }

    /*
     * Hilfsmethode zur Ausgabe einer Map<Double, List<Circle>>
     */
    private static void printMapOfCircles(Map<Double, List<Circle>> map)
    {
        // MUSS NICHT, KANN DIREKT IN MAIN, HILFT ABER
    }

    public static void main(String[] args)
    {
        System.out.printf("%n%n ---------------------- list1 und list2 ----------------------%n%n");
        List<Circle> list1 = setUpCircleList(10, 6);
        List<Circle> list2 = setUpCircleList(10, 6);
        System.out.println("list1: ");
        list1.forEach(System.out::println);
        System.out.println();
        System.out.println("list2: ");
        list2.forEach(System.out::println);

        System.out.printf("%n%n -------------------- union(list1, list2) --------------------%n%n");
			        /* print List of union(list1, list2)
			        * z.B.:
			            Circle [radius=1.0] area=  3,14 circumference= 6,28
			            Circle [radius=3.0] area= 28,27 circumference=18,85
			            Circle [radius=4.0] area= 50,27 circumference=25,13
			            Circle [radius=5.0] area= 78,54 circumference=31,42
			        */
        //TODO

        System.out.printf("%n%n -------------------- createMap(list1) --------------------%n%n");
			        /* print Map of createMap(list1)
			        * z.B.:
			            -- area =  28,27 --
			            Circle [radius=3.0]
			            Circle [radius=3.0]

			            -- area =  78,54 --
			            Circle [radius=5.0]

			            -- area =   3,14 --
			            Circle [radius=1.0]
			            Circle [radius=1.0]
			            Circle [radius=1.0]
			            Circle [radius=1.0]
			            Circle [radius=1.0]

			            -- area =  50,27 --
			            Circle [radius=4.0]

			            -- area =  12,57 --
			            Circle [radius=2.0]
			        */
        //TODO

        System.out.printf("%n%n -------------------- addListToMap(map,list2) --------------------%n%n");
			        /* print Map of addListToMap(map,list2)
			        * z.B.:
			            -- area =  28,27 --
			            Circle [radius=3.0]
			            Circle [radius=3.0]

			            -- area =  78,54 --
			            Circle [radius=5.0]

			            -- area =   3,14 --
			            Circle [radius=1.0]
			            Circle [radius=1.0]
			            Circle [radius=1.0]
			            Circle [radius=1.0]
			            Circle [radius=1.0]

			            -- area =  50,27 --
			            Circle [radius=4.0]

			            -- area =  12,57 --
			            Circle [radius=2.0]
			        */
        //TODO

        System.out.printf("%n%n -------------------- getFirstCircleOfKey(map,int) --------------------%n%n");
        for(int key = 78; key < 80; key++) {

            //TODO

        }

        System.out.printf("%n%n -------------------- getFirstCircleOfRadius(map,double) --------------------%n%n");
        for(double radius = 5.0; radius < 7.0; radius++) {

            //TODO

        }

        System.out.printf("%n%n -------------------- Circle is Comparable  --------------------%n%n");
        Circle c1 = createCircle(3);
        Circle c2 = createCircle(3);
        System.out.println("c1: " + c1);
        System.out.println("c2: " + c2);

        //TODO

        System.out.printf("%n%n -------------------- createSortedListOfCircles(list) --------------------%n%n");

        //TODO

        System.out.printf("%n%n -------------------- createSortedListOfCirclesEvenRadiiFirst(list) --------------------%n%n");

        //TODO
    }
}
